import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Objects;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();
        root.setPrefSize(600, 600);

        // Araç PNG'sini ekle (örnek: kuzeyden gelen araç)
        ImageView carNorth = new ImageView(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/car1/car1.png"))));
        carNorth.setFitWidth(40);
        carNorth.setFitHeight(60);
        carNorth.setX(280);
        carNorth.setY(0);

        // Trafik ışığı PNG'si (örnek: kuzey ışığı)
        ImageView lightNorth = new ImageView(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/traffic_light_green/traffic_light_green.png"))));
        lightNorth.setFitWidth(30);
        lightNorth.setFitHeight(60);
        lightNorth.setX(220);
        lightNorth.setY(120);

        // Araç için yol (kuzeyden aşağıya)
        Line pathNorth = new Line(300, 0, 300, 300);

        // Animasyon
        PathTransition transitionNorth = new PathTransition();
        transitionNorth.setNode(carNorth);
        transitionNorth.setPath(pathNorth);
        transitionNorth.setDuration(Duration.seconds(4));
        transitionNorth.setCycleCount(PathTransition.INDEFINITE);
        transitionNorth.setAutoReverse(false);
        transitionNorth.play();

        // Diğer yönler için de benzer şekilde araç ve ışık ekleyebilirsin

        root.getChildren().addAll(carNorth, lightNorth);

        Scene scene = new Scene(root);
        primaryStage.setTitle("Kavşak Animasyonu");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}